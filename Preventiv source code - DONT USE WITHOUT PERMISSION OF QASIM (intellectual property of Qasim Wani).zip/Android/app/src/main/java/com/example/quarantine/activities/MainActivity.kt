package com.example.quarantine.activities

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.viewpager.widget.ViewPager
import com.example.quarantine.AppPreference
import com.example.quarantine.R
import com.example.quarantine.adapters.SectionsPagerAdapter
import com.example.quarantine.bluetooth.foreground.FService
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.tabs.TabLayout

class MainActivity : AppCompatActivity() {

    @RequiresApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val sectionsPagerAdapter =
            SectionsPagerAdapter(
                this,
                this.supportFragmentManager
            )
        val appPreferences = AppPreference(this)
        val confidence = appPreferences.getConfidence()

        val mHandler: Handler? = Handler()
        lateinit var mRunnable: Runnable

        val viewPager: ViewPager = findViewById(R.id.view_pager)

        viewPager.adapter = sectionsPagerAdapter
        val tabs: TabLayout = findViewById(R.id.tabs)
        tabs.setupWithViewPager(viewPager)
        val fab: FloatingActionButton = findViewById(R.id.fab)
        fab.setOnClickListener { view ->
            Snackbar.make(view, "Tap the box you most strongly agree with", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show()
        }

        checkPermission()

        /**
         * Launch Service
         */

        Log.i("GetPermission", appPreferences.getPermission().toString())
        //Start service
        mRunnable = Runnable {
            AppPreference(this).setPermission(checkPermission())
            startService()
            mHandler?.postDelayed(mRunnable, 10000)  //repeat
        };

        // Schedule the task to repeat after 1 second
        mHandler?.postDelayed(
            mRunnable, // Runnable
            10000 // Delay in milliseconds
        )
    }
    private fun startService()
    {
        if (!FService.IS_RUNNING) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(Intent(applicationContext, FService::class.java))
            } else {
                startService(Intent(applicationContext, FService::class.java))
            }
        }
    }
    private fun checkPermission(): Boolean {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

                requestPermissions(arrayOf(
                    Manifest.permission.ACCESS_COARSE_LOCATION), 200)

                return false
            }
        }
        return true
    }

    override fun onRequestPermissionsResult(requestCode: Int,
                                            permissions: Array<String>,
                                            grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        for (i in grantResults.indices) {
            if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                this.finish()
                return
            }
        }

    }
}