package com.example.quarantine

import android.bluetooth.BluetoothAdapter

object Utils {
    fun isBluetoothAvailable():Boolean
    {
        val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
        if(bluetoothAdapter != null && bluetoothAdapter.isEnabled && bluetoothAdapter.state == BluetoothAdapter.STATE_ON)
        {
            return true
        }
        return false
    }
}