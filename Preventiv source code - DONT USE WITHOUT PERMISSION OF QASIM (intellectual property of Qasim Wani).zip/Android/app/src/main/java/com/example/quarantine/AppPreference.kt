package com.example.quarantine

import android.content.Context
import android.content.SharedPreferences
import java.util.*

const val PREFERENCE_NAME = "Quarantine"
const val PREFERENCE_APP_LAUNCH_CHOICE = "MuxOnLaunch"
const val CONFIDENCE = "CONFIDENCE"
const val UUID_TOKEN = "UUID"
const val UUID_CONNECTIONS = "CONNECTIONS"
const val UUID_TIMESTAMP = "TIMESTAMP"
const val PERMISSION_GRANTED = "PERMISSION_GRANTED"

class AppPreference(context:Context) {
    private var preference: SharedPreferences = context.getSharedPreferences(PREFERENCE_NAME, Context.MODE_PRIVATE)

    fun setOnAppLaunchInfo(mux:Int){
        val editor = preference.edit()
        editor.putInt(PREFERENCE_APP_LAUNCH_CHOICE, mux)
        editor.apply()
    }
    fun getOnAppLaunchInfo():Int{
        return preference.getInt(PREFERENCE_APP_LAUNCH_CHOICE,0)
    }
    fun setConfidence(set_confidence:Float){
        val editor = preference.edit()
        editor.putFloat(CONFIDENCE, set_confidence)
        editor.apply()
    }
    fun getConfidence():Float{
        return preference.getFloat(CONFIDENCE, -9F)
    }

    /**
     * Sets once in a lifetime random generated UUID
     */
    fun setUUID()
    {
        val editor = preference.edit()
        if(getUUID() == null || getUUID() == "NIL")
        {
            editor.putString(UUID_TOKEN, UUID.randomUUID().toString())
            editor.apply()
        }
    }
    fun getUUID(): String? {
        return preference.getString(UUID_TOKEN, "NIL")
    }

    /**
     * Stores list of UUID (last 10 digits only)
     */
    fun addUUID(uuid: String):Boolean
    {
        if(!isConnection(uuid))
        {
            val editor = preference.edit()
            var getConnections = getConnections()
            getConnections += "$uuid|"
            editor.putString(UUID_CONNECTIONS, getConnections)
            editor.apply()
            return true
        }
        return false //connection probably already exists

    }

    /**
     * Checks if the following UUID is part of the connection.
     * Helper Function for addUUID.
     */
    private fun isConnection(uuid: String):Boolean
    {
        val connections = getConnections()
        if(uuid in connections)
        {
            return true
        }
        return false
    }

    /**
     * Gets list of all connections, delimiter = '|' Type = String.
     */
    fun getConnections():String
    {
        return preference.getString(UUID_CONNECTIONS, "")!!
    }

    /**
     * Stores permission on whether can use Coarse Location for BLE scans
     */
    fun getPermission():Boolean
    {
        return preference.getBoolean(PERMISSION_GRANTED, false)
    }

    /**
     * Sets the permission.
     */
    fun setPermission(mPermission : Boolean)
    {
        val editor = preference.edit()
        editor.putBoolean(PERMISSION_GRANTED, mPermission)
        editor.apply()
    }
}